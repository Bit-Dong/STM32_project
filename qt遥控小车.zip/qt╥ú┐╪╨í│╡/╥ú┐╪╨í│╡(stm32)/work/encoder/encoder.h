//#ifndef __ENCODER_H_
//#define __ENCODER_H_


//void TIM4_Init(u16 per,u16 psc);
//void Change_Target(int t_l,int t_r);

//#endif


