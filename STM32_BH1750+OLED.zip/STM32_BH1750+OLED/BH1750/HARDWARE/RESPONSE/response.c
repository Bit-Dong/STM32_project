#include "response.h"

u8 command;
u8 Download_stu_num[13];
extern u8 audio_flag;
//���ڷ���һ���ֽ�
void MYUSART_SendData1(u8 data)
{
	while((USART1->SR&0X40)==0);
	USART1->DR = data;	 
}

void command_rx(void)
{
  u8 len;
  u8 t;
//	u8 TX_BUF[100];
	if(USART_RX_STA&0X8000)//���յ�����
	{	  		
		if(USART_RX_BUF[1]==0x01)
		{
  		command=0x01;
			USART_RX_STA=0; 
		}
		else if(USART_RX_BUF[1]==0x02)
		{
      command=0x02;
			USART_RX_STA=0; 
		}
		else if(USART_RX_BUF[1]==0x03)
		{
      command=0x03;
			USART_RX_STA=0; 
		}
		else if(USART_RX_BUF[1]==0x04)
		{
      command=0x04;
			audio_flag=1;
			USART_RX_STA=0; 
		}
		else if(USART_RX_BUF[1]==0x05)
		{
      command=0x05;
			USART_RX_STA=0; 
			
//			len=USART_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
		  for( t=4;t<15;t++)
			{
				Download_stu_num[t-4]=USART_RX_BUF[t];
			}
			Download_stu_num[11]='\0';
//			printf("%s",Download_stu_num);
			USART_RX_STA=0; 
		}
		else if(USART_RX_BUF[1]==0x06)
		{
      command=0x06;
			USART_RX_STA=0; 
			MYUSART_SendData1(0x3A);
			MYUSART_SendData1(0x06);
			MYUSART_SendData1(0x00);
			MYUSART_SendData1(0x01);
			MYUSART_SendData1(0x01);
			MYUSART_SendData1(0x00);
			MYUSART_SendData1(0x04);
			MYUSART_SendData1(0x3A);
		}
		else if(USART_RX_BUF[1]==0x07)
		{
      command=0x07;
			USART_RX_STA=0; 
		}
	}
}

