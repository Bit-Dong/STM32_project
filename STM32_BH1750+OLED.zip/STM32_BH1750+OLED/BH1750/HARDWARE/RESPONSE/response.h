#ifndef __RESPONSE_H
#define __RESPONSE_H	 
#include "sys.h" 
#include "usart.h" 
#include "delay.h" 
#include "led.h" 
#include <stdio.h>

void command_rx();
void MYUSART_SendData1(u8 data);

#endif
