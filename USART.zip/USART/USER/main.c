#include "stm32f10x.h"

void USART1_Init()
{
	GPIO_InitTypeDef GPIO_InitStrue;
	USART_InitTypeDef USART_InitStrue;
	NVIC_InitTypeDef NVIC_InitStrue;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);   //使能 USART1，GPIOA 时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	//USART1_TX PA.9  复用推挽输出
	GPIO_InitStrue.GPIO_Mode=GPIO_Mode_AF_PP;  //复用推挽输出
	GPIO_InitStrue.GPIO_Pin=GPIO_Pin_9;    //PA.9 
	GPIO_InitStrue.GPIO_Speed=GPIO_Speed_10MHz;
	GPIO_Init(GPIOA,&GPIO_InitStrue);   //初始化 GPIOA.9 发送端
	
	//USART1_RX PA.10 浮空输入
	GPIO_InitStrue.GPIO_Mode=GPIO_Mode_IN_FLOATING;    // 浮空输入
	GPIO_InitStrue.GPIO_Pin=GPIO_Pin_10;  //PA.10
	GPIO_InitStrue.GPIO_Speed=GPIO_Speed_10MHz;
	GPIO_Init(GPIOA,&GPIO_InitStrue);  //初始化 GPIOA.10 接收端

	//USART 初始化设置
	USART_InitStrue.USART_BaudRate=115200; //设置波特率位115200
	USART_InitStrue.USART_HardwareFlowControl=USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStrue.USART_Mode=USART_Mode_Tx|USART_Mode_Rx ; //收发模式
	USART_InitStrue.USART_Parity=USART_Parity_No;  //无奇偶校验位
	USART_InitStrue.USART_StopBits=USART_StopBits_1; //一个停止位
	USART_InitStrue.USART_WordLength=USART_WordLength_8b;  //字长为八位数据格式

  USART_Init(USART1,&USART_InitStrue); //串口初始化
	USART_Cmd(USART1,ENABLE);//使能串口1
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);//开启接收中断，接收到数据中断
	
	//Usart1 NVIC 中断配置 配置
	NVIC_InitStrue.NVIC_IRQChannel=USART1_IRQn;   //对应中断通道
	NVIC_InitStrue.NVIC_IRQChannelCmd=ENABLE;     //IRQ 通道使能
	NVIC_InitStrue.NVIC_IRQChannelPreemptionPriority=1;    //抢占优先级1
	NVIC_InitStrue.NVIC_IRQChannelSubPriority=1 ;     //子优先级1
	NVIC_Init(&NVIC_InitStrue);    //中断优先级配置
}

void USART1_IRQHandler(void)    //串口1的中断响应函数
{
		u8 res;
		if(USART_GetITStatus(USART1,USART_IT_RXNE))  //判断是否接受中断，如果是串口接受中断，则读取串口接受到的数据
		{
			res= USART_ReceiveData(USART1); //读取接收到的数据
			USART_SendData(USART1,res);
		}
}


 int main(void)
 {	
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //设置 NVIC 中断分组 2
		USART1_Init();
		while(1);

 }
