#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "usart2.h"
#include "esp8266.h"
#include "string.h"
#include "time7.h"
 
/*
项目的主要内容：STM32配合ESP8266模块与服务器数据交互

ESP8266的连接：USART2（PA2、PA3）

如何判断数据接收完全？
1、出现了换行符；
2、如果超过10ms了都没有下一条数据（TIM2来进行10ms的定时）。
*/

 int main(void)
 {		
	 unsigned char*	m=NULL;
	 int flag;
	 LED_Init();
	delay_init();	    	 			//延时函数初始化	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 			//设置NVIC中断分组2:2位抢占优先级，2位响应优先级
	uart_init(115200);	 				//串口初始化为115200
	USART2_init(115200);	 				//串口初始化为115200

	 delay_ms(3000);
	 
	 esp8266_quit_trans();
	esp8266_start_trans();							//esp8266进行初始化
	 
	 
	 esp8266_send_data((u8*)"Hello1\n",500);    
	 esp8266_send_data((u8*)"Hello2\n",500); 
	 esp8266_send_data((u8*)"Hello3\n",500); 
	 flag=1;
	while(1){
 	while(1)
	{
		m=WIFI_Rece_Data();
		if(flag == 1)
		{
			flag = 0;
		}
		else	if(m[0]=='1')
					{
							esp8266_send_data((u8*)"OK1",500); 
							delay_ms(500);
					}
		else	if(m[0]=='2')
					{
							esp8266_send_data((u8*)"OK2",500); 
							delay_ms(500);
					}
		
	}}
 }

 
 

