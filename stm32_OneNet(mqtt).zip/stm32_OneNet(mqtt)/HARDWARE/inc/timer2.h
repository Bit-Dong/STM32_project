
#ifndef _TIMER2_H
#define _TIMER2_H

void TIM2_ENABLE_10S(void);

#endif
