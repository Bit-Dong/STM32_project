#ifndef __DELAY_H
#define __DELAY_H 			   
#include "sys.h"  
	 
void Delay_Init(void);
void DelayMs(u16 nms);
void DelayUs(u32 nus);

#endif
























































