
#ifndef __CONTROL_H
#define __CONTROL_H

int length(int a);
void Send_Data(void);
#endif


