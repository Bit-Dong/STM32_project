#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "sys.h"

void motor_gpio(void);
void go(int i);
void back(int i);
void stop(void);

#endif
