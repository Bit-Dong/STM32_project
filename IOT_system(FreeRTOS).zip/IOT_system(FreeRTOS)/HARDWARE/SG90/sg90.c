#include "sg90.h"

/*
                20msΪ��
        0.5ms ------------ 0�ȣ�
        1.0ms ------------ 45�ȣ�
        1.5ms ------------ 90�ȣ�
        2.0ms ------------ 135�ȣ�
        2.5ms ------------ 180�ȣ�
*/
void SG90_angle(int a)
{
    int pwm=50+200/180*a;
    TIM_SetCompare1(TIM2,pwm);
}    
