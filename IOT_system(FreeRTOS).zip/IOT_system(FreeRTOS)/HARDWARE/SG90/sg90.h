#ifndef __SG90_H
#define __SG90_H	 
#include "sys.h"
#include "pwm.h"

void SG90_angle(int a);

#endif
