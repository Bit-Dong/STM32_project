#ifndef _TIMER7_H
#define _TIMER7_H
#include "sys.h"


void TIM7_Int_Init(u16 arr,u16 psc);

#endif
