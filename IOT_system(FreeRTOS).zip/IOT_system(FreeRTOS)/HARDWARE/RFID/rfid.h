#ifndef RFID_H_
#define RFID_H_

#include "stm32f10x.h"

#define STATUS_OK			0x00
#define STATUS_ERR          0x01

#include <stdio.h>

#define Debug printf


void Delay(__IO unsigned int nCount);

void Uart3_Send_Data(unsigned char *buf,unsigned char num);
unsigned char RxCheckSum(unsigned char *ptr,unsigned char len);
void TxCheckSum(unsigned char *ptr,unsigned char len);
long long int ReadId(unsigned char *idout);


#endif
