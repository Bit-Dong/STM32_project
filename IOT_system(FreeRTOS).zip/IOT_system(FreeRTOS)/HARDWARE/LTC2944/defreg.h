#ifndef __DEFREG_H
#define __DEFREG_H
 //Ԥ�������ѿ�����������������ָʾ��
 
 
 
 
 
 extern unsigned char HeatSwitchOn;
 enum {LowByte,HighByte};
enum {LowLowByte,LowHighByte,HighLowByte,HighHighByte};
#define  DHT11_DATA_IN()	   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)

#define  DHT11_No2_DATA_IN()	   GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_9)


#define  CarTimeAll     10
#define   HeatTimeOKBit  6000


#define    ValidByte      0x55
#define    InValidByte    0xaa
#define    WaringByte    0xcc
#define    HandByte      0x66

#define  Bit_RESET    0
#define  Bit_SET      1

#define  DHT11_NO1    0X11
#define  DHT11_NO2    0X22



#define  In1Times  0
#define  In2Times  1
#define  In3Times  2

#define  TriggerTHold       0xE3
#define  TriggerRHHold      0xE5

#define  TriggerTNoHold       0xF3
#define  TriggerRHNoHold      0xF5

#define  ReadUserReg         0xe7
#define  WriteUserReg        0xe6

#define PeriodTimes          4
 

 
 
#define  Ch455_Addr      0x48
#define  Ch455_SYS       0x01

#define  Ch455_DIG1    0x68
#define  Ch455_DIG2    0x6A
#define  Ch455_DIG3    0x6C
#define  Ch455_DIG4    0x6E


//#define RED     0xf800
//#define GREEN   0x07e0
//#define BLUE    0x001f
//#define YELLOW  0xffe0
//#define CYAN    0x07ff
//#define MAGENTA 0xf81f
//#define BLACK   0x0000
//#define WHITE   0xffff
//#define GRAY    0x8410
 





#define    CH455_SDA_SET      GPIO_SetBits(GPIOB, GPIO_Pin_10)  ///*������ʼ�����������ź�*/
#define    CH455_SCL_SET     GPIO_SetBits(GPIOB, GPIO_Pin_11)	
#define    CH455_SDA_CLR   GPIO_ResetBits(GPIOB, GPIO_Pin_10)/*������ʼ�ź�*/
#define  	 CH455_SCL_CLR   GPIO_ResetBits(GPIOB, GPIO_Pin_11)

////////////////////////
#define    NVD04_SDA_SET    GPIO_SetBits(GPIOE, GPIO_Pin_14)   ///*������ʼ�����������ź�*/
#define    NVD04_SCL_SET    GPIO_SetBits(GPIOE, GPIO_Pin_15)	
#define    NVD04_SDA_CLR    GPIO_ResetBits(GPIOE, GPIO_Pin_14)/*������ʼ�ź�*/
#define 	 NVD04_SCL_CLR    GPIO_ResetBits(GPIOE, GPIO_Pin_15)

#define    HDT11_SAD_SET    GPIO_SetBits(GPIOB, GPIO_Pin_15)
#define    HDT11_SAD_CLR    GPIO_ResetBits(GPIOB, GPIO_Pin_15) 


#define    HDT11_No2_SAD_SET    GPIO_SetBits(GPIOD, GPIO_Pin_9)
#define    HDT11_No2_SAD_CLR    GPIO_ResetBits(GPIOD, GPIO_Pin_9) 




#define    Led_No2_AX_On            SetByteBit3
#define    Led_No2_AX_Off           ClrByteBit3

#define    Led_No2_BX_On            SetByteBit7
#define    Led_No2_BX_Off           ClrByteBit7

#define    Led_No2_CX_On            SetByteBit1
#define    Led_No2_CX_Off           ClrByteBit1

#define    Led_No2_BS_On            SetByteBit2
#define    Led_No2_BS_Off           ClrByteBit2

#define    Led_No2_DX_On            SetByteBit6
#define    Led_No2_DX_Off           ClrByteBit6

#define    Led_No2_CW_On            SetByteBit0
#define    Led_No2_CW_Off           ClrByteBit0

#define    Led_No3_TX1_On            SetByteBit5
#define    Led_No3_TX1_Off           ClrByteBit5

#define    Led_No3_TX2_On            SetByteBit4
#define    Led_No3_TX2_Off           ClrByteBit4

#define    Led_No3_JR_On            SetByteBit3
#define    Led_No3_JR_Off           ClrByteBit3

#define    Led_No3_SD_On            SetByteBit2
#define    Led_No3_SD_Off           ClrByteBit2




#define    Led_No4_Red1_On            SetByteBit5
#define    Led_No4_Red1_Off           ClrByteBit5

#define    Led_No4_Green1_On           SetByteBit4
#define    Led_No4_Green1_Off          ClrByteBit4


#define    Led_No4_Red2_On            SetByteBit3
#define    Led_No4_Red2_Off           ClrByteBit3

#define    Led_No4_Green2_On           SetByteBit2
#define    Led_No4_Green2_Off          ClrByteBit2




#define    Led_No1_Red1_On            SetByteBit2
#define    Led_No1_Red1_Off           ClrByteBit2

#define    Led_No1_Green1_On           SetByteBit3
#define    Led_No1_Green1_Off          ClrByteBit3


#define    Led_No1_Red2_On            SetByteBit6
#define    Led_No1_Red2_Off           ClrByteBit6

#define    Led_No1_Green2_On           SetByteBit7
#define    Led_No1_Green2_Off          ClrByteBit7

#define    Led_No1_Red3_On            SetByteBit4
#define    Led_No1_Red3_Off           ClrByteBit4

#define    Led_No1_Green3_On           SetByteBit5
#define    Led_No1_Green3_Off          ClrByteBit5


#define    Solf_Start_TY_On        GPIO_ResetBits(GPIOD, GPIO_Pin_11);GPIO_SetBits(GPIOD, GPIO_Pin_12) 
#define    Solf_Start_TY_Off       GPIO_SetBits(GPIOD, GPIO_Pin_11)

#define    Solf_Start_Reset_On        GPIO_ResetBits(GPIOD, GPIO_Pin_12);GPIO_SetBits(GPIOD, GPIO_Pin_11) 
#define    Solf_Start_Reset_Off       GPIO_SetBits(GPIOD, GPIO_Pin_12)


#define    Energy_On           GPIO_ResetBits(GPIOB, GPIO_Pin_13); GPIO_SetBits(GPIOB, GPIO_Pin_12) 
#define    Energy_Off          GPIO_ResetBits(GPIOB, GPIO_Pin_12); GPIO_SetBits(GPIOB, GPIO_Pin_13) 


 


#define    ConDXNum      16
#define    PTDXNum       0xff
#define    INDXNum       0xff
#define    ZHZDXNum       10

#define    TXRestCase    0x57E40






#define RealayNo1     0x1
#define RealayNo2     0x2
#define RealayNo3     0x3
#define RealayNo4     0x4
#define RealayNo5     0x5
#define RealayNo6     0x6


#define OnCaseH       0xba
#define OnCaseL       0xcf

#define OffCaseH       0xb7
#define OffCaseL       0xd6
#define RelayRetCase   1200


#define  I1RepCase 0x01
#define  I2RepCase 0x02
#define  I3RepCase 0x04
#define  I0RepCase 0x08
#define  UURepCase  0x10
#define  OURepCase  0x20
#define  ZHZRepCase  0x40

#define  ConErrRepCase  0x80





#define  I1CKCase  0x01
#define  I2CKCase  0x02
#define  I3CKCase  0x04
#define  I0CKCase  0x08
#define  UUCKCase  0x10
#define  OUCKCase  0x20
#define  ZHZCKCase  0x40



#define   Ia		  0
#define   Ib		  1
#define   Ic		  2
#define   Ua		  3
#define   Ub		  4
#define   Uc		  5
#define   P		      6
#define   Q		      7
#define   S 		  8






#define Out5_On  GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define Out4_On  GPIO_ResetBits(GPIOC, GPIO_Pin_7)

#define Out3_On  GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define Out2_On  GPIO_ResetBits(GPIOD, GPIO_Pin_15)//;HeatNo2SwitchOn=0x55;


#define Out1_On   GPIO_ResetBits(GPIOD, GPIO_Pin_14)//;HeatNo1SwitchOn=0x55;
#define Out6_Off  GPIO_ResetBits(GPIOE, GPIO_Pin_13)
 



#define Out5_Off  GPIO_SetBits(GPIOC, GPIO_Pin_8)
#define Out4_Off  GPIO_SetBits(GPIOC, GPIO_Pin_7)

#define Out3_Off  GPIO_SetBits(GPIOC, GPIO_Pin_6)
#define Out2_Off  GPIO_SetBits(GPIOD, GPIO_Pin_15)//;HeatNo2SwitchOn=0xaa;


#define Out1_Off  GPIO_SetBits(GPIOD, GPIO_Pin_14)//;HeatNo1SwitchOn=0xaa;
#define Out6_On   GPIO_SetBits(GPIOE, GPIO_Pin_13)
 

#define PassOffset    0x10

#define SYSOffset     0x20



 
#define SYSLeaf     0x1


#define  AreaOffset   0x20  //�˵�����
#define  AddrOffset   0x22	  //ͨѶ��ַ
#define  SpeedOffset  0x24	  //������
#define  HeatModeOffset 0x26  //����ģʽ
#define  TemperOffset         0x28  //�¶ȶ�ֵ
#define  THysteresisOffset    0x2a   //�¶Ȼ���
#define  HumidityOffset       0x2c   //ʪ�ȶ�ֵ
#define  HHysteresisOffset    0x2e   //ʪ�Ȼ���

#define  THeatOffset        0x30 //������ʱ
#define  TTimeNo1Offset     0x32 //1#ʱ��̵���
#define  TTimeNo2Offset     0x34 //2#ʱ��̵���

#define  SpotOffset      0x36 //�������
#define  SAddrOffset     0x38 //��ʼ��ַ

#define  ConVoiceOffset     0x3a //CT���

#define  ConOutOffset     0x3c	 ///ң��
#define  TPulseOffset     0x3e   //�������
#define  KibOffset        0x40    //��������



#define SetI1          0
#define SetI2          1

#define SetTI2        2
#define SetI3         3
#define SetTI3        4



#define SetTTimeNo1     5
#define SetTTimeNo2     6


#define SetTPulse     8
#define SetTHand      9
#define KRFDTime      10






#define     SysCursory      2
#define     Sys1Cursory     0
#define     Sys2Cursory     45






#define    DZCount   16

#define   No1Cursorx	0
#define   No2Cursorx	2
#define   No3Cursorx	4
#define   No4Cursorx	6

#define   No1Cursory	6
#define   No2Cursory	21
#define   No3Cursory	37
#define   No4Cursory	53
#define   No5Cursory	69
#define   No6Cursory	85
#define   No7Cursory	101
#define   No8Cursory	117


#define     SysData1Cursorx     0
#define     SysData2Cursorx     0


/*
#define    YJWide   64//61
#define    HzWide   24
#define    AIIWide   12
#define    TUWide    122
#define    SetXLine  0xb8
#define    SetYRow   0x40
#define    StartLine 0xc0
#define    HzTotal   350
#define    OnDisp    0x3f
#define    OffDisp   0x3e
#define    RepLen    30 
*/



 
#define    YJWide   64//61
#define    HzWide   24
#define    AIIWide   12
#define    TUWide    122
#define    SetXLine  0xb0
#define    SetYRow   0x10
#define    StartLine 0xc0
#define    HzTotal   350
#define    OnDisp    0xAf
#define    OffDisp   0xAe
#define    RepLen    30 




#define    AttribCase   8
#define    EventNoCase  9

#define    DataAttCase  14

#define    DataHHCase   10
#define    DataHLCase   11
#define    DataLHCase   12
#define    DataLLCase   13
#define    DataTZHX     27




#define    QueueRepStart   0
#define    QueueRepEnd     300

#define    UpRepStart   0
#define    UpRepEnd     300




#define    EEpRepStart   0x200
#define    EEpRepEnd     0x5de

#define    EEpRepStartH   0x2
#define    EEpRepStartL   0x0

#define    EEpRepEndH     0x5
#define    EEpRepEndL     0xde


 


#define    RepHeadPage	   5
#define    RepHeadOffset    0xe0
#define    RepTailOffset    0xe2

#define    RepHeadOffsetH    0xe1
#define    RepHeadOffsetL    0xe0

#define    RepTailOffsetH    0xe3
#define    RepTailOffsetL    0xe2









#define    ClrByteBit    0x00
#define    ClrByteBit0   0xfe
#define    ClrByteBit1   0xfd
#define    ClrByteBit2   0xfb
#define    ClrByteBit3   0xf7
#define    ClrByteBit4   0xef
#define    ClrByteBit5   0xdf
#define    ClrByteBit6   0xbf
#define    ClrByteBit7   0x7f

#define    SetByteBit    0xff
#define    SetByteBit0   0x01
#define    SetByteBit1   0x02
#define    SetByteBit2   0x04
#define    SetByteBit3   0x08

#define    SetByteBit4   0x10
#define    SetByteBit5   0x20
#define    SetByteBit6   0x40
#define    SetByteBit7   0x80


#define    SetByteKR1   0X01
#define    SetByteKR2   0X02
#define    SetByteKR3   0X04
#define    SetByteKR4   0X08
#define    SetByteKR5   0X10
#define    SetByteKR6   0X20
#define    SetByteKR7   0X40
#define    SetByteKR8   0X80



#define    SetByteKR9    0X01
#define    SetByteKR10   0X02
#define    SetByteKR11   0X04
#define    SetByteKR12   0X08
#define    SetByteKR13   0X10
#define    SetByteKR14   0X20
#define    SetByteKR15   0X40
#define    SetByteKR16   0X80


  
 
 
 
 


#define    QueueKeyStart 0
#define    QueueKeyEnd   14

#define SYSCount        50
#define PageNum         5




#define  CSHOffset1        0xf2
#define  CSHOffset2        0xf3
#define  CSHOffset3        0xf4



#define   WaiteRetTime   42000




#define   KeyENT    03

#define   KeyUp      01
#define   KeyDown    02
#define   KeyRight   03
#define   KeyESC     04

#define   ADC_CH1	 12
#define   ADC_CH2	 11
#define   ADC_CH3	 2
#define   ADC_CH4	 10
#define   ADC_CH5	 11
#define   ADC_CH6	 12
#define   ADC_CH7	 1
#define   ADC_CH8	 4




 
#define  NumberKR1	  0
#define  NumberKR2	  1
#define  NumberKR3	  2
#define  NumberKR4	  3
#define  NumberKR5	  4
#define  NumberKR6	  5
#define  NumberKR7	  6
#define  NumberKR8	  7
#define  NumberKR9	  8
#define  NumberKR10	  9
#define  NumberKR11	  10
#define  NumberKR12	  11
#define  NumberKR13	  12
#define  NumberKR14	  13
#define  NumberKR15	  14
#define  NumberKR16	  15


#define  NumberYear   0
#define  NumberMonth  1
#define  NumberDay    2
#define  NumberHour   3
#define  NumberMin    4
#define  NumberSec    5
#define  NumberMsH    6
#define  NumberMsL    7

#define SetByteBitKR1          0x01
#define SetByteBitKR2          0x02
#define SetByteBitKR3          0x04	 
#define SetByteBitKR4          0x08

#define SetByteBitKR5          0x10
#define SetByteBitKR6          0x20
#define SetByteBitKR7          0x40
#define SetByteBitKR8          0x80


#define SetByteBitKR9           0x01
#define SetByteBitKR10          0x02
#define SetByteBitKR11          0x04
#define SetByteBitKR12          0x08

#define SetByteBitKR13          0x10
#define SetByteBitKR14          0x20
#define SetByteBitKR15          0x40
#define SetByteBitKR16          0x80

#define ChangeSetKR1Bit            0x01
#define ChangeSetKR2Bit            0x02
#define ChangeSetKR3Bit            0x04
#define ChangeSetKR4Bit            0x08
#define ChangeSetKR5Bit            0x10
#define ChangeSetKR6Bit            0x20
#define ChangeSetKR7Bit            0x40
#define ChangeSetKR8Bit            0x80
#define ChangeSetKR9Bit            0x01
#define ChangeSetKR10Bit            0x02
#define ChangeSetKR11Bit            0x04
#define ChangeSetKR12Bit            0x08
#define ChangeSetKR13Bit            0x10
#define ChangeSetKR14Bit            0x20
#define ChangeSetKR15Bit            0x40
#define ChangeSetKR16Bit            0x80

#define ChangeClrBit            0



#define  eSetI3Data		   10
#define  eSetU3Data        20


#endif


/******************************************************************************/

