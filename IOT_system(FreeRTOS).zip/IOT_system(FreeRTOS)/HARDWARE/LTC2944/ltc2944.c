/******************************************************************************/
/* LCD_4BIT.C: Functions for 2 line 16 character Text LCD (4-bit interface)   */
/*             connected on MCBSTM32 evaluation board                         */
/******************************************************************************/
/* This file is part of the uVision/ARM development tools.                    */
/* Copyright (c) 2005-2007 Keil Software. All rights reserved.                */
/* This software may only be used under the terms of a valid, current,        */
/* end user licence from KEIL for a compatible version of KEIL software       */
/* development tools. Nothing else gives you the right to use this software.  */
/******************************************************************************/


#include "ltc2944reg.h"
#include "defreg.h"
#include "ltc2944defreg.h"
#include "stdio.h"

/*
    SCL  PA5
    SDA  PA6
*/

/*LTC����*/
signed  int UP[20], DI0[4][10];


union memb10
{
    unsigned int DataWord;
    unsigned char DataByte[2];
} IIC_LTC2944;



union memb11
{
    unsigned int DataWord;
    unsigned char DataByte[2];
} IIC_TempData;

unsigned char LTC2944_EEData,AD_Times;
unsigned char ReadTempBit,ItIsLoadBit,LTC2944_Err;
unsigned int LTC2944_Vol,LTC2944_Cur,LTC2944_Temp,LTC2944_Charge;
unsigned int VLTC2944_Vol,VLTC2944_Cur,VLTC2944_Temp,VLTC2944_Charge;

unsigned long  MaxData,MinData,SumData;
unsigned int  LTC2944[4][300];

void LTC2944_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
 
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin =     GPIO_Pin_5 | GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}




void delay_LTC2944(int cnt)
{
    unsigned  int ii,k;
    for(ii=0; ii<50; ii++)
        for(k=0; k<cnt; k++);
}



void LTC2944_I2c_Start( void )  // ������ʼ
{

    LTC2944_SCL_SET;
    LTC2944_SDA_SET;   //������ʼ�����������ź�


    delay_LTC2944(500);
    LTC2944_SDA_CLR;   //������ʼ�ź�
    delay_LTC2944(500);
    LTC2944_SCL_CLR;   //ǯסI2C���ߣ�׼�����ͻ��������
    delay_LTC2944(500);

}

void LTC2944_I2c_Stop( void )  // ��������
{

    LTC2944_SCL_SET;
    LTC2944_SDA_CLR;
    delay_LTC2944(500);


    LTC2944_SDA_SET;  //����I2C���߽����ź�
    delay_LTC2944(500);


}

int LTC2944_I2c_WrByte( unsigned char EEpData)	//дһ���ֽ�����
{

    unsigned char i,j;
    LTC2944_SCL_CLR;//��������
    for( i = 0; i != 8; i++ )  // ���8λ����
    {
        if( EEpData&0x80 )
        {
            LTC2944_SDA_SET;
        }
        else
        {
            LTC2944_SDA_CLR;
        }

        delay_LTC2944(500);
        LTC2944_SCL_SET;
        EEpData<<= 1;
        delay_LTC2944(500);
        LTC2944_SCL_CLR;
    }
	
    delay_LTC2944(50);

    LTC2944_SDA_SET;

    delay_LTC2944(1000);



    j= LTC2944_DATA_IN();
    if(j!=ACK)
        //LTC2944_Err=ValidByte;
	return -1;
    LTC2944_SCL_SET;  // ����Ӧ��
    delay_LTC2944(500);

    LTC2944_SCL_CLR;

    delay_LTC2944(500);

	return 0;
}

unsigned char   LTC2944_I2c_RdByte( void )		//��һ���ֽ�����
{

    unsigned char  i,j,EEpData;
    EEpData=0;

    ///////////

    LTC2944_SCL_CLR;

    for(i=0; i<8; i++)
    {
        //  ;��������=1
        //	LTC2944_SDA_SET;

        delay_LTC2944(500);




        j= LTC2944_DATA_IN();
        EEpData=(EEpData<<1)|j;
        LTC2944_SCL_SET;
        delay_LTC2944(500);
        LTC2944_SCL_CLR;

    }

    delay_LTC2944(500);

    LTC2944_SDA_SET;       // ������ЧӦ��
    delay_LTC2944(500);
    LTC2944_SCL_SET;
    delay_LTC2944(500);
    LTC2944_SCL_CLR;
    delay_LTC2944(500);


    return(EEpData);


}


unsigned int   LTC2944_I2c_RdWord( void )		//��һ���ֽ�����
{

    unsigned char  i,j,EEpData;
    EEpData=0;

    ///////////

    LTC2944_SCL_CLR;

    for(i=0; i<8; i++)
    {
        //  ;��������=1
        //LTC2944_SDA_SET;

        delay_LTC2944(500);

        j= LTC2944_DATA_IN();
        EEpData=(EEpData<<1)|j;
        LTC2944_SCL_SET;
        delay_LTC2944(500);
        LTC2944_SCL_CLR;

    }

    delay_LTC2944(500);

    LTC2944_SDA_CLR;       // ������ЧӦ��
    delay_LTC2944(500);
    LTC2944_SCL_SET;
    delay_LTC2944(500);
    LTC2944_SCL_CLR;
    // delay_LTC2944(500);

    IIC_TempData.DataByte[HighByte]=EEpData;
    EEpData=0;

    for(i=0; i<8; i++)
    {
        //  ;��������=1
        //LTC2944_SDA_SET;

        delay_LTC2944(500);

        j= LTC2944_DATA_IN();
        EEpData=(EEpData<<1)|j;
        LTC2944_SCL_SET;
        delay_LTC2944(500);
        LTC2944_SCL_CLR;

    }

    delay_LTC2944(500);

    LTC2944_SDA_SET;       // ������ЧӦ��
    delay_LTC2944(500);
    LTC2944_SCL_SET;
    delay_LTC2944(500);
    LTC2944_SCL_CLR;
    delay_LTC2944(500);

    IIC_TempData.DataByte[LowByte]=EEpData;

    return(IIC_TempData.DataWord);


}
////////////////////


unsigned  int   LTC2944_ReadI2CW(unsigned char EEpAddrH,unsigned char EEpAddrL)
{
    unsigned int EEpdata;
    EEpdata=0;

    LTC2944_I2c_Start();
    LTC2944_I2c_WrByte(0xc8);
    LTC2944_I2c_WrByte(EEpAddrH);
    LTC2944_I2c_Start();
    LTC2944_I2c_WrByte(0xc9);
    EEpdata=LTC2944_I2c_RdWord();
    LTC2944_I2c_Stop() ;
    return(EEpdata);

}


unsigned  char   LTC2944_ReadI2C(unsigned char EEpAddr)
{
    unsigned char EEpdata;
    EEpdata=0;

    LTC2944_I2c_Start();
    if (-1 == LTC2944_I2c_WrByte(0xc8))
		printf("read: write 0xc8 failed\r\n");
    if (-1 == LTC2944_I2c_WrByte(EEpAddr))
		printf("read: write 0x%x failed\r\n",EEpAddr);
    LTC2944_I2c_Start();
    if (-1 == LTC2944_I2c_WrByte(0xc9))
		printf("read: write 0xc9 failed\r\n");
    EEpdata=LTC2944_I2c_RdByte();
    LTC2944_I2c_Stop() ;
    return(EEpdata);

}
void  LTC2944_WriteI2C(unsigned char EEpAddr,unsigned char EEpData)
{
    LTC2944_I2c_Start();
    if (-1 == LTC2944_I2c_WrByte(0xc8))
		printf("write 0xc8 faial\r\n");
    if (-1 == LTC2944_I2c_WrByte(EEpAddr))
		printf("write 0x%x faial\r\n",EEpAddr);

    if (-1 == LTC2944_I2c_WrByte(EEpData))
		printf("write 0x%x faial\r\n",EEpData);
    LTC2944_I2c_Stop() ;



    delay_LTC2944(1000);
    delay_LTC2944(1000);
    delay_LTC2944(1000);
    delay_LTC2944(1000);

}




void di_chang(void)
{

    float  ADData;
    //unsigned int TempData;
    //unsigned char ax,bx;



    LTC2944_EEData=LTC2944_ReadI2C(ControlAddr);

    if(LTC2944_EEData==ControlM)
    {
		/*����ѹ*/
        LTC2944_Err=InValidByte;
        IIC_LTC2944.DataWord=LTC2944_ReadI2CW(Voltage_MSB_Offset,Voltage_LSB_Offset); 
		// IIC_LTC2944.DataByte[LowByte]=LTC2944_ReadI2C(Voltage_LSB_Offset);
        if(LTC2944_Err!=ValidByte)
		{
			LTC2944_Vol=IIC_LTC2944.DataWord;
			//printf("V=%x\r\n",LTC2944_Vol);
		}
//		else
//			LTC2944_Err = 0;
		/*�����ѹ*/
        LTC2944[LTC2944V][AD_Times]=LTC2944_Vol;

		/*������*/
        LTC2944_Err=InValidByte;
        IIC_LTC2944.DataWord=LTC2944_ReadI2CW(Current_MSB_Offset,Current_LSB_Offset); 
        //IIC_LTC2944.DataByte[LowByte]=LTC2944_ReadI2C(Current_LSB_Offset);
        if(LTC2944_Err!=ValidByte)
		{
			LTC2944_Cur=IIC_LTC2944.DataWord;
			//printf("I=%x\r\n",LTC2944_Cur);
		}
//		else
//			LTC2944_Err = 0;
		/*�������*/
        LTC2944[LTC2944C][AD_Times]=LTC2944_Cur;

		/*���¶�*/
        LTC2944_Err=InValidByte;
        IIC_LTC2944.DataWord=LTC2944_ReadI2CW(Temp_MSB_Offset,Temp_LSB_Offset); 
		// IIC_LTC2944.DataByte[LowByte]=LTC2944_ReadI2C(Temp_LSB_Offset);
        if(LTC2944_Err!=ValidByte)
		{
			LTC2944_Temp=IIC_LTC2944.DataWord;
			//printf("T=%x\r\n",LTC2944_Temp);
		}
            
//		else
//			LTC2944_Err = 0;
		/*�����¶�*/
        LTC2944[LTC2944T][AD_Times]=LTC2944_Temp;

		/*������*/
        LTC2944_Err=InValidByte;
        IIC_LTC2944.DataWord=LTC2944_ReadI2CW(Charge_MSB_Offset,Charge_LSB_Offset); 
		// IIC_LTC2944.DataByte[LowByte]=LTC2944_ReadI2C(Charge_LSB_Offset);
        if(LTC2944_Err!=ValidByte)
		{
			LTC2944_Charge=IIC_LTC2944.DataWord;
			//printf("C=%x\r\n",LTC2944_Charge);
		}
            
//		else
//			LTC2944_Err = 0;
		/*�������*/
        LTC2944[LTC2944Ch][AD_Times]=LTC2944_Charge;

        AD_Times++;

        if(AD_Times>=250)
        {
            AD_Times=0;
            // Digital_Filter();
        }

		
		/*�����ѹ(V)*/
        ADData=LTC2944_Vol*708/65535;
		
        if(ADData>=Voltage_Drift)  
			ADData=ADData-Voltage_Drift;
        else  
			ADData=0;

        UP[1]=ADData+0.5;

		
		/*�������(mA)*/
        if(LTC2944_Cur<0X8000)
        {
            ItIsLoadBit=ValidByte;

            ADData=0x7fff-LTC2944_Cur;

            ADData=ADData*64000/50;
            ADData=ADData/32767;
            if(ADData<=15)
            {
                ADData=0;
                ItIsLoadBit=ValidByte;
            }
            ADData=ADData*10;

        }
        else
        {
            ItIsLoadBit=InValidByte;
            ADData=LTC2944_Cur-0x7fff;


            ADData=ADData*64000/50;
            ADData=ADData/32767;
            if(ADData<=15)
            {
                ADData=0;
                ItIsLoadBit=ValidByte;
            }
            ADData=ADData*10;
        }
        if(ADData>=Current_Drift)  ADData=ADData-Current_Drift;
        UP[2]=ADData;


		/*�����¶�(C)*/
        ADData=LTC2944_Temp*510/65535;
        ADData=(ADData-273)*10;

        if(ADData>=Temp_Drift)  ADData=ADData-Temp_Drift;
        UP[3]=ADData;

		/*�������(%)*/
        ADData=LTC2944_Charge;

        UP[4]=ADData*1000/0xffff;

    }
}


void  Digital_Filter()
{
    unsigned int ax;
    MaxData=LTC2944[LTC2944V][0];
    MinData=LTC2944[LTC2944V][0];
    SumData=LTC2944[LTC2944V][0];
    for(ax=1; ax<10; ax++)
    {
        if(MaxData<=LTC2944[LTC2944V][ax]) MaxData=LTC2944[LTC2944V][ax];
        if(MinData>=LTC2944[LTC2944V][ax]) MinData=LTC2944[LTC2944V][ax];
        SumData=SumData+LTC2944[LTC2944V][ax];
    }

    SumData=SumData-MaxData-MinData;


    VLTC2944_Vol=SumData/8;                         //��ѹ




    MaxData=LTC2944[LTC2944C][0];
    MinData=LTC2944[LTC2944C][0];
    SumData=LTC2944[LTC2944C][0];
    for(ax=1; ax<10; ax++)
    {
        if(MaxData<=LTC2944[LTC2944C][ax]) MaxData=LTC2944[LTC2944C][ax];
        if(MinData>=LTC2944[LTC2944C][ax]) MinData=LTC2944[LTC2944C][ax];
        SumData=SumData+LTC2944[LTC2944C][ax];
    }

    SumData=SumData-MaxData-MinData;


    VLTC2944_Cur=SumData/8;               //����


    MaxData=LTC2944[LTC2944T][0];
    MinData=LTC2944[LTC2944T][0];
    SumData=LTC2944[LTC2944T][0];
    for(ax=1; ax<10; ax++)
    {
        if(MaxData<=LTC2944[LTC2944T][ax]) MaxData=LTC2944[LTC2944T][ax];
        if(MinData>=LTC2944[LTC2944T][ax]) MinData=LTC2944[LTC2944T][ax];
        SumData=SumData+LTC2944[LTC2944T][ax];
    }

    SumData=SumData-MaxData-MinData;


    VLTC2944_Temp=SumData/8;                      //�¶�



    MaxData=LTC2944[LTC2944Ch][0];
    MinData=LTC2944[LTC2944Ch][0];
    SumData=LTC2944[LTC2944Ch][0];
    for(ax=1; ax<10; ax++)
    {
        if(MaxData<=LTC2944[LTC2944Ch][ax]) MaxData=LTC2944[LTC2944Ch][ax];
        if(MinData>=LTC2944[LTC2944Ch][ax]) MinData=LTC2944[LTC2944Ch][ax];
        SumData=SumData+LTC2944[LTC2944Ch][ax];
    }

    SumData=SumData-MaxData-MinData;


    VLTC2944_Charge=SumData/8;              //���





}


