#ifndef __LTC2944REG_H
#define __LTC2944REG_H


#include "sys.h"              /* STM32F10x Library Definitions      */

#define LTC_CONTROL_ADDR  	0x01

#define V_flag_get_Init_Sta 	1			//�ɼ���ʼ״̬
#define V_flag_get_Now_Sta 		2			//�ɼ���ǰ״̬
#define V_flag_get_Stop_Sta 	0			//ֹͣ�ɼ�



void LTC2944_GPIO_Init(void);
void LTC2944_I2c_Start( void );
void LTC2944_I2c_Stop( void );

int LTC2944_I2c_WrByte( unsigned char EEpData);	//дһ���ֽ�����
//int LTC2944_I2c_WrByte( unsigned char EEpData );
unsigned char   LTC2944_I2c_RdByte( void );
unsigned int    LTC2944_I2c_RdWord( void );

unsigned  char   LTC2944_ReadI2C(unsigned char EEpAddr);
unsigned  int   LTC2944_ReadI2CW(unsigned char EEpAddrH,unsigned char EEpAddrL);

void  LTC2944_WriteI2C(unsigned char EEpAddr,unsigned char EEpData);
void delay_LTC2944(int cnt);
void  Digital_Filter(void);



void di_chang(void);

#endif
