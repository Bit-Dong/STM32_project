#ifndef __LTC2944DEFREG_H
#define __LTC2944DEFREG_H

#define Voltage_MSB_Offset   0x08
#define Voltage_LSB_Offset   0x09

#define Charge_MSB_Offset   0x02
#define Charge_LSB_Offset   0x03


#define Current_MSB_Offset   0x0E
#define Current_LSB_Offset   0x0F


#define Temp_MSB_Offset   0x14
#define Temp_LSB_Offset   0x15

#define  ACK            0
#define  NACK           1
#define  Voltage_Drift  4
#define  Current_Drift  70
#define  Temp_Drift     90

#define  LTC2944V        0
#define  LTC2944C        1
#define  LTC2944T        2
#define  LTC2944Ch       3

#define  ControlM        0xf8
#define  ControlAddr      0x01


//////����
#define    LTC2944_SDA_SET    GPIO_SetBits(GPIOA, GPIO_Pin_6)   ///*������ʼ�����������ź�*/
#define    LTC2944_SCL_SET    GPIO_SetBits(GPIOA, GPIO_Pin_5)
#define    LTC2944_SDA_CLR    GPIO_ResetBits(GPIOA, GPIO_Pin_6)/*������ʼ�ź�*/
#define 	 LTC2944_SCL_CLR    GPIO_ResetBits(GPIOA, GPIO_Pin_5)

#define    LTC2944_DATA_IN()	   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)


//i2c
/*
GPIO_InitStructure.GPIO_Pin =     GPIO_Pin_9 | GPIO_Pin_10;
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
GPIO_Init(GPIOD, &GPIO_InitStructure);
*/

#endif

