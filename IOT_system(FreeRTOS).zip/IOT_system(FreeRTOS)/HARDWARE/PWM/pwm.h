#ifndef __PWM_H
#define __PWM_H	 
#include "sys.h"

void TIM2_PWM_Init(u16 per,u16 psc);

#endif
