#ifndef UART3_H_
#define UART3_H_

#include <stdio.h>

#define Debug printf


void uart3_init(void);

#define USART3_MAX_RECV_LEN		600					//�����ջ����ֽ���

#define UART1_RX_BUF_LEN  30

#define Uart3_RX_BUF_LEN  30

#endif
