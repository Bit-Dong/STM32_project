#include "stm32f10x.h"                  // Device header
#include "PWM.h"
#include "Delay.h"
void Servo_Init(void)
{
	Angle++;
		
		if(Angle>8)
		{
			Angle = 2;
		}
		Delay_ms(2000);
}

