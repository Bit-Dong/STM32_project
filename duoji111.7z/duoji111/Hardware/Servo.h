#ifndef __SERVO_H
#define __SERVO_H

void Servo_Init(void);

#endif
