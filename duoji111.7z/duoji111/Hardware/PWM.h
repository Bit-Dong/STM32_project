#ifndef __PWM_H
#define __PWM_H
#include "stm32f10x.h"                  // Device header

void PWM_Init(void);
void TIM2_IRQHandler(void);



extern u8 Angle;
#endif
