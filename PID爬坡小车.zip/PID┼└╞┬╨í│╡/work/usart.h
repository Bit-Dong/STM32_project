//#ifndef  __USART_H__
//#define  __USART_H__

//#include "stm32f10x.h"                  // Device header
//#include "stdio.h"


//#define USART1_RCV_LEN 200

////extern uint8_t USART1_RX_BUF[USART1_RCV_LEN];
////extern uint16_t USART1_RX_STA;

//void Usart_Init(void);

//#endif



