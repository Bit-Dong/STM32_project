#ifndef _PWM_H
#define _PWM_H

void TIM1_PWM_Init(u16 per,u16 psc);

#endif

