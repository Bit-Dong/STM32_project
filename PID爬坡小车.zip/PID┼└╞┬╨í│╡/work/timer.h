#ifndef __TIMER_H_
#define __TIMER_H_

void TIM2_Init(u16 per,u16 psc);
void TIM3_Init(u16 per,u16 psc);

#endif

