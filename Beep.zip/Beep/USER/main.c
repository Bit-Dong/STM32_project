#include "sys.h"	
#include "delay.h"	
#include "led.h" 
#include "beep.h" 


 int main(void)
 {
	delay_init();	    	 //延时函数初始化	  
	LED_Init();		  	 	//初始化与LED连接的硬件接口
	BEEP_Init();         	//初始化蜂鸣器端口
	while(1)
	{
		LED0=0;
		BEEP=0;		  
		delay_ms(300);//延时300ms
		LED0=1;	  
		BEEP=1;  
		delay_ms(300);//延时300ms
	}
 }


 
 
 