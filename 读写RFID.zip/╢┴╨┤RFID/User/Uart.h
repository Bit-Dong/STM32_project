#ifndef UART_H
#define UART_H

#include <stdio.h>

#define Debug printf

//void COM1_Init( void);
void COM1_2_Init( void);

#define USART2_MAX_RECV_LEN		600					//�����ջ����ֽ���

#define UART1_RX_BUF_LEN  30

#define UART2_RX_BUF_LEN  30

#endif
