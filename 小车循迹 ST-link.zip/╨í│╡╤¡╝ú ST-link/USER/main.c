#include "stm32f10x.h"
#include "xunji.h"
#include "delay.h"


 void Init()
{
	TIM_SetCompare1(TIM4,25);
	TIM_SetCompare3(TIM4,25);
	IN1=1;
	IN2=0;
	IN3=1;
	IN4=0;
}
 
 int main(void)
 {	

		motor_gpio();
		xunji_gpio();
		pwm();             
		delay_init();
	  Init();
			while(1)
			{

					if(LEFT_ONE==0&&LEFT_TWO==0)
					{
							 run();
					}
					
					else if(LEFT_ONE==0&&LEFT_TWO==1)
					{
					
							right();
					}
					
					else if(LEFT_ONE==1&&LEFT_TWO==0)
					{
					
							left();
					}
					
		      else if(LEFT_ONE==1&&LEFT_TWO==1)
					{
					
							run();
					}
					
					else
						stop();
				
			 }
	
}

