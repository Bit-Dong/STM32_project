#include "ctrl.h"
#include "time.h"


void ctrl(void){
	SET_MOTOR=1;
	TIM_SetCompare2(TIM2,50);
	
}




