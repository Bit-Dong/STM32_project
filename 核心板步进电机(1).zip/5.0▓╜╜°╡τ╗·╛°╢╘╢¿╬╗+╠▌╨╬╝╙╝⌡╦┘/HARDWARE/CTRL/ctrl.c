#include "ctrl.h"
#include "time.h"
#include "key.h"
int angle = 0;
void ctrl(void){
	if(WK_UP==1){
		Locate_Abs(8000,0,5000,200,&Motor2);
	}
	if(KEY0==1){
	Locate_Abs(0,0,5000,200,&Motor2);
	}
}




