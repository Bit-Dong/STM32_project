#ifndef __CTRL_H
#define __CTRL_H	 
#include "sys.h"




void ctrl(void);


		 				    
#endif




