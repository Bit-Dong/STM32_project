#include "ctrl.h"
#include "time.h"
#include "key.h"
int angle = 0;
void ctrl(void){
	if(WK_UP==1){
		step_angle2pulse(360);
		step_angle2pulse_porONE(360);
	}
}




