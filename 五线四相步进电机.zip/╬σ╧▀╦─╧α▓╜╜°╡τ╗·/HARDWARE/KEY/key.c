#include "key.h"
#include "delay.h"
unsigned char  Indepedent_Key_State[4]={1,1,1,1};
unsigned char  Indepedent_Key_Last_State[4]={1,1,1,1};
 
void KEY_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOE,ENABLE);	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE,&GPIO_InitStruct);
	
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
}
void Indepedent_Key_Scan(void)//����ɨ��
{
	unsigned char i;
	unsigned char tmp=1;
	static unsigned char Indepedent_Key_Buf[4]={0xff,0xff,0xff}; //��������ɨ���������
	for(i=0;i<3;i++)
	{
		switch(i)
		{
			case 0: tmp=GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4);break;
			case 1: tmp=GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3);break;
      case 2: tmp=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0);break;
      default:break;				
		 }		
		Indepedent_Key_Buf[i] = ((Indepedent_Key_Buf[i])<<1)|tmp;	
	 }
 
	for(i=0;i<3;i++)
  {
		if((Indepedent_Key_Buf[i]&0xff)==0)
		{  
			 //����8��ɨ��ֵΪ0����8ms�ڶ��ǰ���״̬������Ϊ�������ȶ��ذ���
       Indepedent_Key_State[i]=1;			
		 }	
		else if ((Indepedent_Key_Buf[i]&0xff)==0xff)
		{   //����8��ɨ��ֵΪ1����8ms�ڶ��ǵ���״̬ʱ������Ϊ�������ȶ��ص���
			  Indepedent_Key_State[i]=0;
		 }	 
		else
		{;}
	 }	
}
unsigned char Get_Indepedent_Key_Value(void)
 {
	  unsigned char i;
	  unsigned char tmp=20;
	  unsigned char Value=20;
    for(i=0;i<3;i++)
    {
			
					if(Indepedent_Key_State[i]!=Indepedent_Key_Last_State[i])
					{
						if(Indepedent_Key_State[i]==1)
						{ tmp=i;}
						Indepedent_Key_Last_State[i] = Indepedent_Key_State[i];	
					 }
	   }
     switch(tmp)
		 {
			 case 0: Value = KEY0_BASE;break;
			 case 1: Value = KEY1_BASE; break; 
			 case 2: Value = KEY_UP_BASE; break; 
		   default: break; 
		 } 
		 return Value;    	
 }
 
