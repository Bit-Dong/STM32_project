#include "motor.h"
#include "sys.h"

unsigned int Zz_flag = 0;
unsigned int Fz_flag = 0;
unsigned int Zz_Value = 0;
unsigned int Fz_Value = 0;

void Motor_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	//GPIO_ResetBits(GPIOC,GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9);
}
 
void Motor_Zz(void)//��ת
{
	Zz_Value = 1;
	Fz_Value = 0;
}
void Motor_Fz(void)//��ת
{
	Fz_Value = 1;
	Zz_Value = 0;
}
void Motor_Stop(void)
{
	Zz_Value = 0;
	Fz_Value = 0;
	Motor_A = 0;
	Motor_B = 0;
	Motor_C = 0;
	Motor_D = 0;
}
void Motor_Zz_Function(void)
{
			switch(Zz_flag)//����
		{
			case 0 : Motor_A = 1;Motor_B = 0;Motor_C = 0; Motor_D = 0;Zz_flag++;break;//A
			
			case 1 : Motor_A = 1;Motor_B = 1;Motor_C = 0; Motor_D = 0;Zz_flag++;break;//AB
			
			case 2 : Motor_A = 0;Motor_B = 1;Motor_C = 0; Motor_D = 0;Zz_flag++;break;//B
			
			case 3 : Motor_A = 0;Motor_B = 1;Motor_C = 1; Motor_D = 0;Zz_flag++;break;//BC
			
			case 4 : Motor_A = 0;Motor_B = 0;Motor_C = 1; Motor_D = 0;Zz_flag++;break;//C
			
			case 5 : Motor_A = 0;Motor_B = 0;Motor_C = 1; Motor_D = 1;Zz_flag++;break;//CD
			
			case 6 : Motor_A = 0;Motor_B = 0;Motor_C = 0; Motor_D = 1;Zz_flag++;break;//D
			
			case 7 : Motor_A = 1;Motor_B = 0;Motor_C = 0; Motor_D = 1;Zz_flag = 0;break;//DA
			
			default : break;
			
		}
}
void Motor_Fz_Function(void)
{
	switch(Fz_flag)
		{
			case 0 : Motor_A = 1;Motor_B = 0;Motor_C = 0; Motor_D = 1;Fz_flag++;break;//DA
			
			case 1 : Motor_A = 0;Motor_B = 0;Motor_C = 0; Motor_D = 1;Fz_flag++;break;//D
			
			case 2 : Motor_A = 0;Motor_B = 0;Motor_C = 1; Motor_D = 1;Fz_flag++;break;//CD
			
			case 3 : Motor_A = 0;Motor_B = 0;Motor_C = 1; Motor_D = 0;Fz_flag++;break;//C
			
			case 4 : Motor_A = 0;Motor_B = 1;Motor_C = 1; Motor_D = 0;Fz_flag++;break;//BC
			
			case 5 : Motor_A = 0;Motor_B = 1;Motor_C = 0; Motor_D = 0;Fz_flag++;break;//B
			
			case 6 : Motor_A = 1;Motor_B = 1;Motor_C = 0; Motor_D = 0;Fz_flag++;break;//AB
			
			case 7 : Motor_A = 1;Motor_B = 0;Motor_C = 0; Motor_D = 0;Fz_flag=0;break;//A
			
			default : break;
			
		}
}
