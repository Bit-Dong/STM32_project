#ifndef __MOTOR__H
#define __MOTOR__H
#include "sys.h"
 
#define Motor_A  PCout(6)
#define Motor_B  PCout(7)
#define Motor_C  PCout(8)
#define Motor_D  PCout(9)
 
extern unsigned int Zz_flag;
extern unsigned int Fz_flag;
extern unsigned int Zz_Value;
extern unsigned int Fz_Value;
extern unsigned int Fz_Value;
 
 
 void Motor_Zz_Function(void);
 void Motor_Fz_Function(void);
 void Motor_Init(void);
 void Motor_Zz(void);//��ת
 void Motor_Fz(void);//��ת
#endif
