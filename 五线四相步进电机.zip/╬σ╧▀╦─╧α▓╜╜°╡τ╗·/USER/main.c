#include "timer.h"
#include "motor.h"
#include "key.h"
#include "delay.h"
int main()
{
	int key = 0;
	int arr = 50;
	int Motor_flag = 0;
	TIM3_init(99,7199);
	Motor_Init();
	KEY_Init();
	Motor_Zz();
	while(1)
	{
		
		key = Get_Indepedent_Key_Value();
		if(key) 
		{
			switch(key)
			{
				case KEY0_BASE : arr += 10; TIM_SetAutoreload(TIM3,arr);break;
				
				case KEY1_BASE : arr -= 10; TIM_SetAutoreload(TIM3,arr);break;
				
				case KEY_UP_BASE : if(Motor_flag % 2 == 0) Motor_Fz(); else Motor_Zz(); Motor_flag++;break;
				
				default : break;
			}
		} 
			
	}
}
